﻿using LotteryBallGeneratorTest.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LotteryBallGeneratorTest.Models
{
    public class LotteryBallsViewModel
    {
        public List<LotteryBall> LotteryBallList { get; set; }
        
    }
}
