﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LotteryBallGeneratorTest.Data
{
    public interface ILotteryUtility
    {
        List<LotteryBall> GenerateListOfLotteryBalls(List<int> chosenBalls);
        List<LotteryBall> AssignBallColour(List<LotteryBall> lotteryBalls);
        List<int> NumberGenerator(int maxRndNumbers);

    }
}
