﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LotteryBallGeneratorTest.Data
{
    public class LotteryUtility : ILotteryUtility
    {

        /// <summary>
        /// Generateds a list of lottery balls using LotteryBall class
        /// </summary>
        /// <param name="chosenBalls"></param>
        /// <returns></returns>
        public List<LotteryBall> GenerateListOfLotteryBalls(List<int> chosenBalls)
        {
            var lotteryBallsList = new List<LotteryBall>();
            if (chosenBalls.Count == 0) return lotteryBallsList; // empty throw back

            // Add number to the LotteryBall list ( could be further scope to do more stuff in here)
            foreach (var item in chosenBalls)
            {
                lotteryBallsList.Add(new LotteryBall { BallNumber = item, BonusBall= false });
            }

            return lotteryBallsList;
        }

        /// <summary>
        /// Assigns a colour to the ball 
        /// </summary>
        /// <param name="lotteryBalls"></param>
        /// <returns></returns>
        public List<LotteryBall> AssignBallColour(List<LotteryBall> lotteryBalls)
        {
            // Assgen a colour dependant on number 
            // Could be replaced with css class names, but just use colour names for now
            foreach (var item in lotteryBalls)
            {
                switch (item.BallNumber)
                {
                    case int n when (n <= 10):
                        item.Colour = "grey";
                        break;

                    case int n when (n > 10 && n < 20):
                        item.Colour = "blue";
                        break;

                    case int n when (n >= 20 && n < 30):
                        item.Colour = "pink";
                        break;

                    case int n when (n >= 30 && n < 40):
                        item.Colour = "green";
                        break;

                    case int n when (n >= 40 && n < 50):
                        item.Colour = "yellow";
                        break;

                }
            }

            return lotteryBalls;
        }

        /// <summary>
        /// Generates a radom number between 1 - 49 (hard coded for now)
        /// </summary>
        /// <param name="maxRndNumbers"></param>
        /// <returns></returns>
        public List<int> NumberGenerator(int maxRndNumbers)
        {
            // Create a list of numbers 1 - 49
            // Randomly pick six numbers from list 
            // order list ascending and return
            // linq ensures that number is only selected once

            var rnd = new Random();
            var rndNumbers = Enumerable.Range(1, 49).OrderBy(x => rnd.Next()).Take(maxRndNumbers);
            var orderListOfInts = rndNumbers.OrderBy(p => p).ToList();
            return orderListOfInts;
        }
    }
}
