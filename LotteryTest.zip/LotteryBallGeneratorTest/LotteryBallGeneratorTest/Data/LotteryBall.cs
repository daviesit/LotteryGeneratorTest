﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LotteryBallGeneratorTest.Data
{
    public class LotteryBall
    {
        public int BallNumber { get; set; }
        public string Colour { get; set; }
        public bool  BonusBall { get; set; }
    }
}
