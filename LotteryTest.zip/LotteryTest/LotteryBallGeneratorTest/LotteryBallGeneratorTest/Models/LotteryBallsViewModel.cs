﻿using LotteryBallGeneratorTest.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LotteryBallGeneratorTest.Models
{
    public class LotteryBallsViewModel
    {
        public List<LotteryBall> LotteryBallList { get; set; }
        public LotteryBall BonusBall { get; set; } // I've set an extra property for bounus ball, but could be added to list above
    }
}
