﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using LotteryBallGeneratorTest.Models;
using LotteryBallGeneratorTest.Data;

namespace LotteryBallGeneratorTest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ILotteryUtility _lotteryUtility;
        private const int _maxGeneratedNumbers = 6;

        public HomeController(ILogger<HomeController> logger,
                               ILotteryUtility lotteryUtility)
        {
            _logger = logger;
            _lotteryUtility = lotteryUtility; // ref startup.cs
        }

        public IActionResult Index()
        {
            // Generate random lottery balls & return it to view
            var lotteryBallsViewModel = GenerateRandomBalls(_maxGeneratedNumbers);

            return View(lotteryBallsViewModel);
        }


        /// <summary>
        /// Set of sequences that generate numbers, assign colours and returns a view
        /// </summary>
        /// <returns></returns>
        private LotteryBallsViewModel GenerateRandomBalls(int maxGeneratedNumbers)
        {
            var lotteryBallsViewModel = new LotteryBallsViewModel();
            var generatedNumbers = _lotteryUtility.NumberGenerator(maxGeneratedNumbers);
            var listOfLotteryBalls = _lotteryUtility.GenerateListOfLotteryBalls(generatedNumbers);
            var listOfLotteryBallsWithColour = _lotteryUtility.AssignBallColour(listOfLotteryBalls);

            lotteryBallsViewModel.LotteryBallList = listOfLotteryBallsWithColour;
            return lotteryBallsViewModel;
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
